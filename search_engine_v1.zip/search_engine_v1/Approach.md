
# Semantic Search Engine

By- Ayush Kumar (kayush206@gmail.com)

## Idea:
=======

"Principle behind the embeddings is, the words that are used in the same contexts tend to have similar meanings. A key feature of embedding (LSI) is its ability to extract the conceptual content of a body of text by establishing associations between those terms that occur in similar contexts."

Here is my approach in attempt to build semantic seach engine:

1. read the dataset file (`"data/top_500_lateral_wiki_utf8.csv"`) and then create a new file (`"data/input_doc_sent.txt"`) which is correctly formated as expected by Starspacess's train and push the articles informations to `mongodb` instances.

2. When create_index is invoked then, Starspce begins the training on `data/input_doc_sent.txt` with `trainMode=2`, `epoch=20`, `threads=10` and `similarity=dot`. After training, we save the model in `model` directory. Then I prepare the embedding vector of each document and finally creat the `nmslib` index and save the index in model directory. this index will be used whenever we want to closest vector for a given vector. This step is very time consuming depending on size of dataset and compute resources we have.

3. when query is invoked then, we load the starspace emebedding generator and get the embeddings for given query expression. And then we load the nmslib index and get the nearset data points from index.


**Here, I am triaing with smaller dataset since large dataset(`data/lateral_wiki_50k_sample.csv`) is too long to `create_index`.**


A lot of time has been invested in environment preparation using docker image/cantainer. To avoid duplicacy of that i have put the image in dockerhub. 

## Implementation Details:
=========================

All the changes are within the scope of backend component and within `/backend` directory.  
Replaced the `indexer.py` with `semantic_search.py` and following are the primary methods of semantic_search.py:  

### Loads data and preprocesses for `Starspace`:    
    def upload(articles: Collection, int_to_articles: Collection, filename: str) -> int

### Generating the document embeddings and creating the `nmslib` index for fast query
    def create_embedding_index(articles: Collection) -> Tuple[int, int]

### Query for some expression 
    def query(expr: str, offset: int, limit: int, articles: Collection, int_to_articles: Collection) -> List[SearchResult]

there are some other auxiliary methods as well.

## How to use :
=============

To get started you will first need to install [Docker desktop](https://www.docker.com/products/docker-desktop). This works well on Ubuntu and Mac laptops. However, on Windows you might need a Linux VM if you encounter issues.

---

Next build the development environment as follows (this will take a minute or so):

NOTE: Following step for `backend` component, can take a lot of time as there is several python dependecies and building the [Starspace](https://github.com/facebookresearch/StarSpace) steps. To avoid this time consuming step, you can use the pre built image for backend component. 

To enable this speedup, open the `docker-compose.yml` and comment the `Line 16` and uncomment the `Line 17`.

    docker-compose build

Now, you can bring up docker containers in the background:

    docker-compose up -d

You should be able to list the running containers:

    docker ps
```
CONTAINER ID        IMAGE                          COMMAND                  CREATED             STATUS              PORTS                    NAMES
9d2288047c25        search_engine_v1_react-app     "docker-entrypoint.s…"   4 minutes ago       Up 4 minutes        0.0.0.0:3000->3000/tcp   search_engine_v1_react-app_1
307bb5857c9b        search_engine_v1_pure-js-app   "docker-entrypoint.s…"   4 minutes ago       Up 4 minutes        0.0.0.0:3001->3001/tcp   search_engine_v1_pure-js-app_1
19545d67bfbf        search_engine_v1_vue-app       "docker-entrypoint.s…"   4 minutes ago       Up 4 minutes        0.0.0.0:8080->8080/tcp   search_engine_v1_vue-app_1
adac06ac5eb9        search_engine_v1_backend       "bash -c 'cp /Starsp…"   4 minutes ago       Up 4 minutes        0.0.0.0:5000->5000/tcp   search_engine_v1_backend_1
401346ff01d2        mongo:latest                   "docker-entrypoint.s…"   4 minutes ago       Up 4 minutes        27017/tcp                search_engine_v1_mongo_1
d5980f59e632        redis:latest                   "docker-entrypoint.s…"   4 minutes ago       Up 4 minutes        6379/tcp                 search_engine_v1_redis_1

```

You can constantly `monitor the log of backend container`:

    docker logs -f search_engine_v1_backend_1

```
 * Serving Flask app "app.py" (lazy loading)
 * Environment: development
 * Debug mode: on
 * Running on http://0.0.0.0:5000/ (Press CTRL+C to quit)
 * Restarting with stat
 * Debugger is active!
 * Debugger PIN: 717-186-022
Your CPU supports instructions that this binary was not compiled to use: SSE3 SSE4.1 SSE4.2 AVX AVX2
For maximum performance, you can install NMSLIB from sources 
pip install --no-binary :all: nmslib
[2021-04-19 00:50:58,329] INFO in app: initialized flask, CORS, and MongoClient
Your CPU supports instructions that this binary was not compiled to use: SSE3 SSE4.1 SSE4.2 AVX AVX2
For maximum performance, you can install NMSLIB from sources 
pip install --no-binary :all: nmslib
[2021-04-19 00:50:58,857] INFO in app: initialized flask, CORS, and MongoClient
[2021-04-19 00:51:21,351] INFO in app: upload_articles
172.28.0.1 - - [19/Apr/2021 00:51:23] "GET /upload_data HTTP/1.1" 200 -
[2021-04-19 00:51:26,631] INFO in app: lookup wikipedia-20968452
172.28.0.1 - - [19/Apr/2021 00:51:26] "GET /lookup/wikipedia-20968452 HTTP/1.1" 200 -
[2021-04-19 00:51:40,059] INFO in app: started create_index
Start to initialize starspace model.
Build dict from input file : data/input_doc_sent.txt
Read 0M words
Number of words in dictionary:  10718
Number of labels in dictionary: 0
Loading data from file : data/input_doc_sent.txt
Total number of examples loaded : 500
Initialized model weights. Model size :
matrix : 10718 100
Training epoch 0: 0.05 0.0025
Training epoch 1: 0.0475 0.0025
Training epoch 2: 0.045 0.0025
Training epoch 3: 0.0425 0.0025
Training epoch 4: 0.04 0.0025
Training epoch 5: 0.0375 0.0025
Training epoch 6: 0.035 0.0025
Training epoch 7: 0.0325 0.0025
Training epoch 8: 0.03 0.0025
Training epoch 9: 0.0275 0.0025
Training epoch 10: 0.025 0.0025
Training epoch 11: 0.0225 0.0025
Training epoch 12: 0.02 0.0025
Training epoch 13: 0.0175 0.0025
Training epoch 14: 0.015 0.0025
Training epoch 15: 0.0125 0.0025
Training epoch 16: 0.01 0.0025
Training epoch 17: 0.0075 0.0025
Training epoch 18: 0.005 0.0025
Training epoch 19: 0.0025 0.0025
Saving model in tsv format : model/wiki_doc_embedding.tsv
Start to load a trained embedding model in tsv format.
Loading dict from model file : model/wiki_doc_embedding.tsv
Number of words in dictionary:  10718
Number of labels in dictionary: 0
Initialized model weights. Model size :
matrix : 10718 100
Loading model from file model/wiki_doc_embedding.tsv
Model loaded.
Epoch: 97.4%  lr: 0.002500  loss: 0.134887  eta: <1min   tot: 0h0m51s  (99.9%)
0%   10   20   30   40   50   60   70   80   90   100%
|----|----|----|----|----|----|----|----|----|----|
***************************************************

0%   10   20   30   40   50   60   70   80   90   100%
|----|----|----|----|----|----|----|----|----|----|
****************************************************


[2021-04-19 00:52:35,522] INFO in app: finished create_index
172.28.0.1 - - [19/Apr/2021 00:52:35] "GET /create_index HTTP/1.1" 200 -
```

---
## Load data and preprocessing for Starspace

First we will load all the wikipedia articles in the file `backend/data/top_500_lateral_wiki_utf8.csv` into the mongodb collection called `articles` using the `upload_data` API endpoint.

    curl http://0.0.0.0:5000/upload_data

```
{
  "count": 500
}
```

The code for the backend is in the `/backend/semantic_search.py` file and the API endpoints are defined in `/backend/app.py`. Any changes made to those files are immediately reflected in the API.

## Lookup for the article

Verify that you can now view a single document using its identifier with the `lookup` endpoint.

    curl http://0.0.0.0:5000/lookup/wikipedia-20968452

```
{
    "_id": "wikipedia-20968452",
    "body": "T-code  A transaction code (or t-code) consists of letters, numbers, or both, and is entered in the command field. Each function in SAP ERP has an SAP transaction code associated with it.  Use. A t-code is used to access functions in a SAP application more rapidly. By entering a t-code instead of using the menu, navigation and execution are combined into a single step, much like shortcuts in the Windows OS.",
    "title": "T-code"
}
```

## Generating the document embeddings and creating the nmslib index for fast query

Now we can begin the training of `Starspace` on documents and get the embedding vector of 100 dim for each document. (this will take a few minutes).

Note: We can play around with training hyperparameters of Starspace based on the dataset size and compute power i.e. epoch, threads and etc. 

    curl http://0.0.0.0:5000/create_index

```
{
    "Embedding Dimension": 100,
    "Embeddings Count": 500
}
```
## Query for some expression 

And search for an expression such as "transaction code"

    curl "http://0.0.0.0:5000/search?q=transaction+code&offset=0&limit=10"

```
{
    "results": [
        {
            "_id": "wikipedia-20968452",
            "distance": "-0.57186997",
            "title:": "T-code"
        },
        {
            "_id": "wikipedia-1882576",
            "distance": "-0.5589305",
            "title:": "Area code 321"
        },
        {
            "_id": "wikipedia-7202313",
            "distance": "-0.38643986",
            "title:": "Electrical code"
        },
        {
            "_id": "wikipedia-31478243",
            "distance": "-0.3496331",
            "title:": "2011–12 Chelsea F.C. season"
        },
        {
            "_id": "wikipedia-3353857",
            "distance": "-0.31358004",
            "title:": "Kopaonik"
        },
        {
            "_id": "wikipedia-2348117",
            "distance": "-0.30312523",
            "title:": "Meidum"
        },
        {
            "_id": "wikipedia-1706860",
            "distance": "-0.28428012",
            "title:": "Bayesian experimental design"
        },
        {
            "_id": "wikipedia-406260",
            "distance": "-0.28212613",
            "title:": "Environmental remediation"
        },
        {
            "_id": "wikipedia-185140",
            "distance": "-0.2692575",
            "title:": "Banaadir"
        },
        {
            "_id": "wikipedia-25597820",
            "distance": "-0.26523465",
            "title:": "Lucretia Mott"
        }
    ]
}
```

References:
1. [Starspace github](https://github.com/facebookresearch/StarSpace) 
2. [nmslib github](https://github.com/nmslib/nmslib)
3. [nmslib python documentation](https://nmslib.github.io/nmslib/api.html#nmslib-init)
4. [ArticleSpace github](https://github.com/facebookresearch/StarSpace#articlespace-learning-sentence-and-article-embeddings)