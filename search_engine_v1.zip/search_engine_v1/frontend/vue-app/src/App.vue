<template>
  <!--Copyright 2021 DevRev Inc.-->
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png" class="logo" />
  </div>
</template>

<script>
export default {
  name: "App",
  components: {},
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.logo {
  height: 300px;
}
</style>
