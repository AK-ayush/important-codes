import os

import numpy as np
import pandas as pd 

from nltk.tokenize import sent_tokenize

from pymongo.collection import Collection
from pymongo.errors import DuplicateKeyError

from collections import Counter
from typing import List, Dict, Tuple

from index_interface import SearchResult

# import scann  # facing issue in installation with alpine
import starwrap as sw
import nmslib



def get_title_and_body(content: str) -> Tuple[str, str]:
    title, body = content.split("  ", 1)
    # remove leading quote in title
    if title[0] == '"':
        title = title[1:].lstrip()
    # remove trailing quote in body
    if body[-1] == '"':
        body = body[:-1].rstrip()
    # restrict title to at most 10 words
    if len(title) > 10:
        title = " ".join(title.split(" ")[:10])
    return title, body

def load_starspace():
    arg = sw.args()
    arg.thread = 14
    arg.normalizeText = True
    arg.verbose = True
    arg.trainMode = 2

    sp = sw.starSpace(arg)

    # sp.initFromSavedModel('model/wiki_doc_embedding')
    sp.initFromTsv('model/wiki_doc_embedding.tsv')
    return sp

def train_embeddings():
    arg = sw.args()
    
    arg.trainFile = 'data/input_doc_sent.txt'
    arg.trainMode = 2
    arg.initRandSd = 0.01
    arg.adagrad = True
    arg.ngrams = 1
    arg.lr = 0.05
    arg.epoch = 20
    arg.thread = 14
    arg.dim = 100
    arg.negSearchLimit = 5
    arg.maxNegSamples = 3
    arg.dropoutRHS = 0.8
    arg.fileFormat = 'labelDoc'
    arg.similarity = 'dot' #'cosine' 
    arg.minCount = 5
    arg.normalizeText = True
    arg.trainWord = True    # whether to train word level together with other tasks (for multi-tasking). [0]
    arg.verbose = True
    
    sp = sw.starSpace(arg)
    sp.init()
    sp.train()

    # sp.saveModel('model/wiki_doc_embedding')
    sp.saveModelTsv('model/wiki_doc_embedding.tsv')

    return load_starspace()

def read_data_pandas(fname):
    df = pd.read_csv(fname, header = None, names = ["doc_id", "title_body"])
    
    # trim double quotes 
    df["title_body"] = df["title_body"].str.strip()
    df["title_body"] = df["title_body"].str.strip('"')
    df["title_body"] = df["title_body"].str.replace('"', "'")
    df.title_body.to_csv("data/title_body.txt", header=False, index=None)
    df['title'] = [content[0] for content in  df["title_body"].str.split('  ', 1)] ## TODO optimize it
    # print(df.head())
    print("********* Parsed the input file *********")
    print("Num Records : ", df.doc_id.unique().shape[0])
    num_doc = df.doc_id.unique().shape[0]
    vec_dim = 100
    sent_text = '\n'.join(['\t'.join(st) for st in df.title_body.apply(sent_tokenize)])
    with open("data/input_doc_sent.txt", 'w') as f:
        f.write(sent_text)
    
    return df.doc_id.to_list(), df.title.to_list(), df.title_body.to_list()

def read_data(filename):
    with open(filename) as fp:
        num_doc = 0
        doc_id_list = []
        title_list = []
        content_list = [] 
        for line in fp:
            if len(line) == 0:
                continue
            fields = line.split(",", 1)
            doc_id = fields[0].strip()
            content = fields[1].strip().strip('"')
            title, _ = get_title_and_body(content)
            doc_id_list.append(doc_id)
            title_list.append(title)
            content_list.append(content)
            
            num_doc += 1
    print("********* Parsed the input file *********")
    vec_dim = 100
    sent_text = '\n'.join(['\t'.join(sent_tokenize(content)) for content in content_list])
    with open("data/input_doc_sent.txt", 'w') as f:
        f.write(sent_text)

    return doc_id_list, title_list, content_list
  
def upload(articles: Collection, int_to_articles: Collection, filename: str) -> int:
    doc_id_list, title_list, content_list = read_data_pandas(filename)
    # doc_id_list, title_list, content_list = read_data(filename)  # if pandas is not installed
    id = 0
    for doc_id, title, content in zip(doc_id_list, title_list, content_list):
        document = {"_id": doc_id, "title": title, "body": content}
        mapping = {"_intId": int(id), "doc_id": doc_id}
        try:
            articles.insert_one(document)
        except DuplicateKeyError:
            articles.update_one({"_id": doc_id}, {"$set": { "title": title, "body": content}})
        int_to_articles.insert_one(mapping)
        id += 1
    return id

def create_embedding_index(articles: Collection) -> Tuple[int, int]:

    print("********* Creating document embeddings *********")
    sp = train_embeddings()
    num_doc = articles.count()
    vec_dim = 100
    doc_embed_vec = np.array([np.array(sp.getDocVector(doc["body"], ' ')) for doc in articles.find()]).reshape(num_doc, vec_dim).astype(np.float32)
    # print(doc_embed_vec.shape)

    # Create index from the document embeddings and save it
    index = nmslib.init(method='hnsw', space='negdotprod')
    index.addDataPointBatch(doc_embed_vec) 
    index.createIndex({'post': 2}, print_progress=True)
    index.saveIndex('model/documents_index.bin', save_data=False)

    return (doc_embed_vec.shape)

def query(expr: str, offset: int, limit: int, articles: Collection, int_to_articles: Collection) -> List[SearchResult]:

    newIndex = nmslib.init(method='hnsw', space='negdotprod')
    newIndex.loadIndex('model/documents_index.bin')

    sp = load_starspace()
    vec = np.array(sp.getDocVector(expr, ' '))

    ids, distances = newIndex.knnQuery(vec, k=offset+limit)

    ids = ids[offset:offset+limit]
    distances = distances[offset:offset+limit]

    final_results = []
    for id, dist in zip(ids, distances):    
        result = int_to_articles.find_one({"_intId": int(id)})
        if result :
            doc_id = result["doc_id"]
            result = articles.find_one({"_id": doc_id})
            final_results.append(SearchResult(result["_id"], result["title"], dist,))
    return final_results