from dataclasses import dataclass

@dataclass
class SearchResult:
    """SearchResult is a struct with information that is returned to the user"""

    docid: str
    title: str
    distance: float = 0.0
