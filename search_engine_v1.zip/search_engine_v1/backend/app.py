from flask import Flask, request
from flask_cors import CORS
from urllib.parse import unquote_plus
from pymongo import MongoClient


import semantic_search 

app = Flask(__name__)
CORS(app)  # to allow the web application to access this app
appdb = MongoClient("mongodb://root:Secret@mongo").appdb
app.logger.info("initialized flask, CORS, and MongoClient")


@app.route("/upload_data")
def upload_articles():
    app.logger.info("upload_articles")
    # upload all the articles from the data directory into a new articles collection
    num = semantic_search.upload(appdb.articles, appdb.int_to_articles, "data/top_500_lateral_wiki_utf8.csv")
    # num = semantic_search.upload(appdb.articles, appdb.int_to_articles, "data/lateral_wiki_50k_sample.csv")
    return {"count": num}


@app.route("/lookup/<string:article_id>")
def lookup(article_id):
    app.logger.info(f'lookup {article_id}')
    try:
        return appdb.articles.find({"_id": article_id}).next()
    except StopIteration:
        return {}


@app.route("/create_index")
def create_index():
    app.logger.info("started create_index")
    # index all the documents in mongodb
    num_emb, vec_dim = semantic_search.create_embedding_index(appdb.articles)
    app.logger.info("finished create_index")
    return {"Embeddings Count": num_emb, "Embedding Dimension": vec_dim}


@app.route("/search", methods=['GET'])
def search():
    searched_expression = request.args.get('q', "")
    offset = int(request.args.get('offset', 0))
    limit = int(request.args.get('limit', 10))
    expr = unquote_plus(searched_expression)
    app.logger.info(f"search expr {expr} offset {offset} limit {limit} articles {appdb.articles} ")
    results = semantic_search.query(expr, offset, limit, appdb.articles, appdb.int_to_articles)
    return {"results": [{"_id": res.docid, "title:": res.title, "distance": str(res.distance) } for res in results]}
