import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Flights {

    static final String JDBC_DRIVER = "com.omnisci.jdbc.OmniSciDriver";
    static final String DB_URL = "jdbc:omnisci:localhost:6274:omnisci";
    static final String USER = "omnisci";
    static final String PASS = "HyperInteractive";

    public static void main(String[] args) throws SQLException {
        Connection conn = null;
        Statement stmt = null;
        try {
            Class.forName(JDBC_DRIVER);

            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            System.out.println(conn);
            stmt = conn.createStatement();
            String sql = "CREATE table flights(arr_timestamp timestamp, dep_timestamp timestamp, uniquecarrier varchar(50))";
            stmt.executeUpdate(sql);
            sql = "insert into flights values('2017-04-23 06:30:0', '2017-04-23 07:45:00', 'Southwest')";
            stmt.executeUpdate(sql);
            sql = "insert into flights values('2017-04-23 06:50:0', '2017-04-23 09:45:00', 'American')";
            stmt.executeUpdate(sql);
            sql = "insert into flights values('2017-04-23 09:30:0', '2017-04-23 12:45:00', 'United')";
            stmt.executeUpdate(sql);

            sql = "SELECT uniquecarrier from flights";
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                String uniquecarrier = rs.getString("uniquecarrier");
                System.out.println("uniquecarrier: " + uniquecarrier);
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
            if (stmt != null)
                stmt.close();
            if (conn != null)
                conn.close();
        }
    }
}