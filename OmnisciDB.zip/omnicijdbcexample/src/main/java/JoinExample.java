/*
 *  // to execute this example in command line
 *  javac JoinExample.java
 *  java -cp /omnisci/bin/omnisci-jdbc-5.3.1.jar:./ JoinExample
 *
 *
 *
 * */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JoinExample {

    static final String JDBC_DRIVER = "com.omnisci.jdbc.OmniSciDriver";
    static final String DB_URL = "jdbc:omnisci:localhost:6274:omnisci";
    static final String USER = "admin";
    static final String PASS = "HyperInteractive";

    public static void main(String[] args) throws SQLException {

        Connection conn = null;
        Statement stmt = null;
        try {
            Class.forName(JDBC_DRIVER);

            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            System.out.println(conn);
            stmt = conn.createStatement();
            String sql;

            // create mb_scan table
            sql = "CREATE table mb_scan( " +
                    "   visit_nbr int, " +
                    "   store_nbr int, " +
                    "   visit_date timestamp, " +
                    "   scan_type int, " +
                    "   mds_fam_id int, " +
                    "   unit_qty float, " +
                    "   scan_cnt int, " +
                    "   retail_price float, " +
                    "   unit_cost float, " +
                    "   returned_item_ind int " +
                    ")";
            stmt.execute(sql);

            // create item_dim table
            sql = "CREATE table itm_dim( " +
                    "  mds_fam_id int, " +
                    "  item_nbr int, " +
                    "  upc_nbr bigint, " +
                    "  dept_nbr int, " +
                    "  subclass_nbr int, " +
                    "  fineline_nbr int, " +
                    "  acctg_dept_nbr int, " +
                    "  dept_subcatg_nbr int, " +
                    "  dept_category_nbr int, " +
                    "  dept_catg_grp_nbr int, " +
                    "  mdse_subgroup_nbr int, " +
                    "  mdse_segment_nbr int, " +
                    "  vendor_nbr int, " +
                    "  vendor_dept_nbr int, " +
                    "  vendor_seq_nbr int, " +
                    "  brand_id int, " +
                    "  item_weight_qty float, " +
                    "  all_links_mds_fam_id int, " +
                    "  prime_xref_item_nbr int " +
                    ")";
            stmt.execute(sql);

            sql = "COPY mb_scan FROM 'mb_scan_table.csv' WITH (threads = 4)";
            stmt.executeUpdate(sql);
            sql = "COPY itm_dim FROM 'itm_dim_table.csv' WITH (threads = 4)";
            stmt.executeUpdate(sql);

            sql = "SELECT mb_scan.visit_date, itm_dim.mds_fam_id " +
                    "FROM mb_scan " +
                    "LEFT JOIN itm_dim ON mb_scan.mds_fam_id=itm_dim.mds_fam_id LIMIT 20";
            ResultSet rs = stmt.executeQuery(sql);

            System.out.println("visit_date" + " | " + "mds_fam_id");
            while (rs.next()) {
                System.out.println(rs.getString("visit_date")
                        +" | "+ rs.getString("mds_fam_id"));
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
            if (stmt != null)
                stmt.close();
            if (conn != null)
                conn.close();
        }
    }
}